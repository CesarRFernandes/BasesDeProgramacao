package view;
import view.Janela;

public class Programa {
    public static void main(String[] args) {
        new Janela();
    }
} 